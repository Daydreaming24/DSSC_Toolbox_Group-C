from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

from rdflib import Graph, Namespace, RDF, RDFS, URIRef

from validation_common import CheckResult, MODEL_DIR, ROOT, VALIDATION_DIR, relative, write_report


BE = Namespace("https://w3id.org/dssc-demo/building-energy#")
OWL = Namespace("http://www.w3.org/2002/07/owl#")
SH = Namespace("http://www.w3.org/ns/shacl#")
DCT = Namespace("http://purl.org/dc/terms/")

MAPPING_PATH = ROOT / "mappings" / "external-standard-alignment.sssom.tsv"
QUALITY_PATH = ROOT / "quality" / "model-quality-assessment.md"

def be_term(local_name: str) -> str:
    return str(BE[local_name])


METADATA_FIELDS = {
    "datasetId": str(DCT.identifier),
    "providerName": be_term("providerName"),
    "endpointUrl": be_term("endpointUrl"),
    "format": be_term("format"),
    "frequency": be_term("frequency"),
    "unit": be_term("unit"),
    "spatialCoverage": be_term("spatialCoverage"),
    "temporalStart": be_term("temporalStart"),
    "temporalEnd": be_term("temporalEnd"),
}

RECORD_FIELDS = {
    "buildingId": be_term("buildingId"),
    "meterId": be_term("meterId"),
    "timestamp": be_term("timestamp"),
    "energyKWh": be_term("energyKWh"),
    "unit": be_term("unit"),
    "location": be_term("location"),
}

EXPECTED_COLUMNS = [
    "subject_id",
    "subject_label",
    "predicate_id",
    "object_id",
    "object_label",
    "mapping_justification",
    "confidence",
    "author_id",
    "mapping_date",
    "comment",
]


@dataclass
class ConstraintMetrics:
    required_count: int
    restricted_count: int


def load_sssom_rows() -> list[dict[str, str]]:
    with MAPPING_PATH.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != EXPECTED_COLUMNS:
            raise ValueError(f"Unexpected SSSOM columns: {reader.fieldnames}")
        rows = list(reader)
    if not rows:
        raise ValueError("SSSOM table has no rows.")
    for index, row in enumerate(rows, start=2):
        missing = [column for column in EXPECTED_COLUMNS if not row.get(column)]
        if missing:
            raise ValueError(f"SSSOM row {index} has empty required cells: {missing}")
        float(row["confidence"])
    return rows


def parse_graph(path: Path) -> Graph:
    graph = Graph()
    graph.parse(path.as_uri(), format="turtle")
    return graph


def local_modeled_terms() -> set[str]:
    graph = parse_graph(MODEL_DIR / "v0.3" / "building-energy-ontology.ttl")
    terms: set[str] = set()
    for rdf_type in (OWL.Class, OWL.DatatypeProperty, OWL.ObjectProperty):
        for subject in graph.subjects(RDF.type, rdf_type):
            if isinstance(subject, URIRef) and str(subject).startswith(str(BE)):
                terms.add(str(subject))
    return terms


def mapped_local_terms(rows: list[dict[str, str]]) -> set[str]:
    terms = set()
    for row in rows:
        subject_id = row["subject_id"]
        if subject_id.startswith("be:"):
            terms.add(str(BE[subject_id.removeprefix("be:")]))
        elif subject_id == "dct:identifier":
            terms.add(str(DCT.identifier))
    return terms


def shape_paths(shape_path: Path) -> set[str]:
    graph = parse_graph(shape_path)
    paths = set()
    for path in graph.objects(None, SH.path):
        if isinstance(path, URIRef):
            paths.add(str(path))
    return paths


def field_coverage() -> tuple[int, int, float, list[str]]:
    metadata_paths = shape_paths(MODEL_DIR / "v0.3" / "data-product-metadata-shapes.ttl")
    record_paths = shape_paths(MODEL_DIR / "v0.3" / "energy-reading-record-shapes.ttl")
    expected = {**METADATA_FIELDS, **{f"record.{k}": v for k, v in RECORD_FIELDS.items()}}
    represented = set(metadata_paths) | set(record_paths)
    missing = [name for name, iri in expected.items() if iri not in represented]
    represented_count = len(expected) - len(missing)
    total = len(expected)
    return represented_count, total, represented_count / total, missing


def constraint_metrics(shape_path: Path) -> ConstraintMetrics:
    graph = parse_graph(shape_path)
    required_count = len(list(graph.triples((None, SH.minCount, None))))
    restricted_predicates = {SH["in"], SH.datatype, SH.nodeKind, SH.minInclusive}
    restricted_count = sum(1 for predicate in restricted_predicates for _ in graph.triples((None, predicate, None)))
    return ConstraintMetrics(required_count=required_count, restricted_count=restricted_count)


def write_quality_report(rows: list[dict[str, str]]) -> dict[str, object]:
    QUALITY_PATH.parent.mkdir(parents=True, exist_ok=True)

    local_terms = local_modeled_terms()
    mapped_terms = mapped_local_terms(rows)
    mapped_be_terms = {term for term in mapped_terms if term in local_terms}
    reuse_ratio = len(mapped_be_terms) / len(local_terms)

    covered, total, coverage_ratio, missing = field_coverage()

    v01 = constraint_metrics(MODEL_DIR / "v0.1" / "data-product-metadata-shapes.ttl")
    v02 = constraint_metrics(MODEL_DIR / "v0.2" / "data-product-metadata-shapes.ttl")
    v03_meta = constraint_metrics(MODEL_DIR / "v0.3" / "data-product-metadata-shapes.ttl")
    v03_record = constraint_metrics(MODEL_DIR / "v0.3" / "energy-reading-record-shapes.ttl")

    metrics = {
        "field_coverage": coverage_ratio,
        "field_covered": covered,
        "field_total": total,
        "reuse_ratio": reuse_ratio,
        "mapped_local_terms": len(mapped_be_terms),
        "local_terms": len(local_terms),
        "mapping_rows": len(rows),
    }

    lines = [
        "# Model Quality Assessment",
        "",
        "## Coverage",
        "",
        f"- Required fields represented in v0.3 shapes: {covered}/{total} ({coverage_ratio:.2%})",
        f"- Missing required fields: {', '.join(missing) if missing else 'none'}",
        "",
        "## Constraint Strength",
        "",
        "| Version | Required field constraints | Restricted value/type/node constraints | Interpretation |",
        "|---|---:|---:|---|",
        f"| v0.1 metadata | {v01.required_count} | {v01.restricted_count} | Baseline metadata requirements only. |",
        f"| v0.2 metadata | {v02.required_count} | {v02.restricted_count} | Stricter onboarding validation for endpoint, unit, and temporal coverage. |",
        f"| v0.3 metadata | {v03_meta.required_count} | {v03_meta.restricted_count} | Same metadata contract as v0.2. |",
        f"| v0.3 record | {v03_record.required_count} | {v03_record.restricted_count} | Payload-level constraints for Energy Reading Record. |",
        "",
        "## Reuse Ratio",
        "",
        f"- Local modeled terms in v0.3 ontology: {len(local_terms)}",
        f"- Local modeled terms aligned in SSSOM: {len(mapped_be_terms)}",
        f"- Reuse ratio: {len(mapped_be_terms)}/{len(local_terms)} ({reuse_ratio:.2%})",
        f"- SSSOM mapping rows: {len(rows)}",
        "",
        "The reuse ratio is computed from actual v0.3 ontology local terms and the unique local `be:*` subjects in `mappings/external-standard-alignment.sssom.tsv`.",
        "",
        "## Breaking-Change Risk",
        "",
        "### v0.1 -> v0.2",
        "",
        "Classification: stricter minor change with validation impact.",
        "",
        "- Added required `endpointUrl`, `unit`, `temporalStart`, and `temporalEnd` constraints.",
        "- A Group impact: data offering metadata must include endpoint, unit, and temporal coverage before publication.",
        "- D Group impact: validator shapes reject incomplete v0.1-style metadata under v0.2 rules.",
        "",
        "### v0.2 -> v0.3",
        "",
        "Classification: additive extension.",
        "",
        "- Metadata constraints remain compatible with v0.2.",
        "- Energy Reading Record payload model, SHACL shape, JSON Schema, and OpenAPI fragment are added.",
        "- A Group impact: connector/API documentation can reference the record schema.",
        "- D Group impact: payload validation can be added as an optional second validation layer without breaking metadata validation.",
        "",
        "## Interpretation",
        "",
        "The model is small but standards-aligned. Metadata fields are validated for onboarding, record fields are represented as a payload profile, and local terms are mapped to DCAT/DCTERMS, SOSA/SSN, QUDT/UCUM, OWL-Time, and schema.org patterns.",
        "",
        "## Limitations",
        "",
        "- Provider, location, and temporal coverage are still lightweight literals/objects rather than full organization, place, or OWL-Time interval nodes.",
        "- Unit is validated as the literal `kWh`; richer profiles should use QUDT or UCUM identifiers directly.",
        "- Reuse ratio measures mapping coverage, not full semantic equivalence.",
        "- Constraint strength is a count-based indicator; it does not assess business adequacy of each constraint.",
        "",
    ]
    QUALITY_PATH.write_text("\n".join(lines), encoding="utf-8")
    return metrics


def main() -> int:
    results: list[CheckResult] = []
    try:
        rows = load_sssom_rows()
        results.append(CheckResult("SSSOM TSV is parseable", True, f"`{relative(MAPPING_PATH)}` contains {len(rows)} mapping rows."))
    except Exception as exc:
        rows = []
        results.append(CheckResult("SSSOM TSV is parseable", False, f"{exc.__class__.__name__}: {exc}"))

    if rows:
        try:
            metrics = write_quality_report(rows)
            detail = [
                f"Quality report: `{relative(QUALITY_PATH)}`",
                f"Field coverage: {metrics['field_covered']}/{metrics['field_total']} ({metrics['field_coverage']:.2%})",
                f"Reuse ratio: {metrics['mapped_local_terms']}/{metrics['local_terms']} ({metrics['reuse_ratio']:.2%})",
                f"SSSOM rows: {metrics['mapping_rows']}",
            ]
            results.append(CheckResult("Quality metrics computed", True, "\n".join(detail)))
        except Exception as exc:
            results.append(CheckResult("Quality metrics computed", False, f"{exc.__class__.__name__}: {exc}"))

    ok = write_report(
        VALIDATION_DIR / "quality-metrics-report.md",
        "Quality Metrics Validation Report",
        results,
        notes=["Detailed quality interpretation is written to `quality/model-quality-assessment.md`."],
    )
    print(f"Quality metrics report: {relative(VALIDATION_DIR / 'quality-metrics-report.md')}")
    print(f"Model quality assessment: {relative(QUALITY_PATH)}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
