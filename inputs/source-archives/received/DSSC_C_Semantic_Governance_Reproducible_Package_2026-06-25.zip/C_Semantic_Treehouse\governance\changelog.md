# Changelog

## v0.3 - Record Payload Schema Extension

Added:

- `be:EnergyReadingRecord` class.
- Energy Reading Record fields: `buildingId`, `meterId`, `timestamp`, `energyKWh`, `unit`, `location`.
- Record-level SHACL shape.
- Energy Reading Record JSON-LD context.
- Energy Reading Record JSON Schema.
- OpenAPI fragment for `GET /energy/buildings/hourly`.
- SPARQL competency questions covering metadata and record fields.

Compatibility:

- Additive extension from v0.2.
- Metadata constraints remain compatible with v0.2.
- A Group can attach the record schema to API/offering documentation.
- D Group can optionally validate record payloads without changing metadata validation.

## v0.2 - Stricter Metadata Constraints

Added:

- `endpointUrl`
- `unit`
- `temporalStart`
- `temporalEnd`
- controlled values for `format = JSON`, `frequency = hourly`, and `unit = kWh`
- invalid metadata example for validation failure demonstration

Compatibility:

- Stricter minor change from v0.1 with validation impact.
- A Group must include endpoint, unit, and temporal coverage in offering metadata.
- D Group must update SHACL shapes to reject incomplete v0.1-style metadata.

## v0.1 - Baseline Metadata

Added:

- `be:DataProductMetadata` class.
- baseline fields: `datasetId`, `providerName`, `format`, `frequency`, `spatialCoverage`.
- baseline metadata SHACL shape.
- JSON-LD context and valid metadata example.

Compatibility:

- Initial version.
