$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDir = Split-Path -Parent $ScriptDir
$EvidenceDir = Join-Path $PackageDir "evidence"
$PsFile = Join-Path $EvidenceDir "treehouse-docker-ps.txt"
$SmokeFile = Join-Path $EvidenceDir "treehouse-smoke-check.txt"
$ProjectName = "dssc_treehouse_evidence"

New-Item -ItemType Directory -Force $EvidenceDir | Out-Null
docker ps --filter "label=com.docker.compose.project=$ProjectName" *> $PsFile
Get-Content -Raw -Encoding UTF8 $PsFile
if (Test-Path $SmokeFile) {
    Write-Output ""
    Write-Output "Smoke check:"
    Get-Content -Raw -Encoding UTF8 $SmokeFile
}
