# Semantic Treehouse Local Evidence Track

## Objective

This directory is a non-blocking evidence track for trying a local Semantic Treehouse deployment. It supports the C Group task by documenting whether a local UI/API instance can be cloned, started, inspected, and used as supporting evidence.

The semantic model package does not depend on Semantic Treehouse being available. Independent validation through `make validate` remains the authoritative path for RDF, JSON-LD, SHACL, JSON Schema, OpenAPI, SPARQL, quality, and governance checks.

## Docker Prerequisite

Required tools:

- Git
- Docker
- Docker Compose v2
- A POSIX shell for `Makefile` targets on Unix-like systems
- PowerShell for the Windows `make.cmd` wrapper

## Expected Ports

No fixed port is assumed. The harness inspects upstream Docker Compose files and records any host ports it can detect. If a port is detected, the harness attempts a lightweight localhost smoke check and writes the result to `C_Semantic_Treehouse/evidence/treehouse-smoke-check.txt`.

## Relation to C Group Task

This evidence track supports `C_semantic_treehouse_usage.md` by capturing:

- upstream source revision
- Docker/Compose environment
- deployment commands and logs
- container status
- UI/API URL candidates
- failures and interpretation

## Known Risks

- Semantic Treehouse may not provide a simple Docker Compose deployment path.
- Upstream deployment may require secrets, external services, Kubernetes, Helm, or a database.
- Local Docker credential configuration can block image pulls.
- Port mappings may differ across upstream versions.

## Fallback

If deployment fails, record the failure honestly. The C Group deliverables still remain valid through the independent validation harness:

```sh
make validate
```

On Windows without GNU Make:

```bat
cmd /c make validate
```
