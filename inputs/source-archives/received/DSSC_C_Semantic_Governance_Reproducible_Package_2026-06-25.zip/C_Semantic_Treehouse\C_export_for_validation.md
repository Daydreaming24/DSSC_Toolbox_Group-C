# C Export For Validation

## Exported Artifacts

Core v0.3 exports:

- Ontology: `model/v0.3/building-energy-ontology.ttl`
- Metadata SHACL: `model/v0.3/data-product-metadata-shapes.ttl`
- Record SHACL: `model/v0.3/energy-reading-record-shapes.ttl`
- Data product JSON-LD context: `model/v0.3/data-product-context.jsonld`
- Record JSON-LD context: `model/v0.3/energy-reading-record-context.jsonld`
- Data product valid example: `model/v0.3/data-product-valid.jsonld`
- Record valid example: `model/v0.3/energy-reading-record-valid.jsonld`
- Record invalid example: `model/v0.3/energy-reading-record-invalid.jsonld`
- JSON Schema: `model/v0.3/energy-reading-record.schema.json`
- OpenAPI fragment: `model/v0.3/openapi-fragment.yaml`
- SSSOM mappings: `mappings/external-standard-alignment.sssom.tsv`

## SHACL Shapes Summary

`DataProductMetadataShape-v0_3` requires:

- `dct:identifier` as one string
- `be:providerName` as one string
- `be:endpointUrl` as one IRI
- `be:format = JSON`
- `be:frequency = hourly`
- `be:unit = kWh`
- `be:spatialCoverage` as one string
- `be:temporalStart` as `xsd:date`
- `be:temporalEnd` as `xsd:date`

`EnergyReadingRecordShape-v0_3` requires:

- `buildingId`, `meterId`, `timestamp`, `energyKWh`, `unit`, `location`
- `timestamp` as `xsd:dateTime`
- `energyKWh` non-negative
- `unit = kWh`

## JSON-LD Context Summary

The JSON-LD contexts preserve operational field names while binding them to RDF properties. Metadata examples use `dct:conformsTo` to declare the model version. Record examples use the record context for the API payload shape.

## JSON Schema / OpenAPI Summary

`energy-reading-record.schema.json` validates one record object with required building, meter, timestamp, numeric energy, unit, and location fields. `openapi-fragment.yaml` describes `GET /energy/buildings/hourly`, returning an array of `EnergyReadingRecord` objects.

## Valid Examples

- `model/v0.1/data-product-valid.jsonld`
- `model/v0.2/data-product-valid.jsonld`
- `model/v0.3/data-product-valid.jsonld`
- `model/v0.3/energy-reading-record-valid.jsonld`

## Invalid Examples

- `model/v0.2/data-product-invalid.jsonld`
- `model/v0.3/energy-reading-record-invalid.jsonld`

The invalid metadata intentionally omits `providerName`, uses `unit = MWh`, and omits `temporalEnd`. The invalid record intentionally violates required field, type/format, and unit constraints.

## Expected Validation Results

`validation/all-validations-report.md` reports overall `PASS`.

Expected outcomes:

- RDF/Turtle parse: pass
- JSON-LD expansion: pass
- SHACL valid metadata: pass
- SHACL invalid metadata: fail for expected reasons, counted as harness pass
- SHACL valid record: pass
- JSON Schema valid record: pass
- JSON Schema invalid record: fail for expected reasons, counted as harness pass
- OpenAPI structure: pass
- SPARQL competency questions: pass

## Comparison With Existing `building-energy-shapes.ttl`

Existing file: `DSSC_Tool_Learning/DSSC_Minimal_Energy_Scenario/shapes/building-energy-shapes.ttl`.

That earlier shape targets `dcat:Dataset` and uses a mix of `ex:*`, `dct:*`, and `dcat:*` properties. It requires fields similar to the C model, including provider, endpoint, format, unit, spatial coverage, and temporal coverage.

Key differences:

- The C model uses a stable package namespace `be:` and version IRIs.
- The C model maps `datasetId` directly to `dct:identifier`, while the earlier shape uses `ex:datasetId`.
- The earlier shape requires `dct:title`; the C assignment field list does not include title, so title is not required.
- The earlier shape uses `dcat:endpointURL`; the C model uses local `be:endpointUrl` as a subproperty of `dcat:endpointURL`.
- The earlier shape expects `dct:format = application/json`; the C model constrains the assignment field value to `JSON`.
- The C model adds versioned examples, JSON-LD context, JSON Schema, OpenAPI, SSSOM, SPARQL tests, quality metrics, and governance metadata.

## Validator Options: Semantic Treehouse, SEMIC Validator, pySHACL

- Semantic Treehouse: governance and export evidence track. Local UI smoke succeeded on `http://localhost:4200/`; full UI export workflow still needs manual screenshot evidence.
- SEMIC Validator: can be used by D Group or ITB-style workflows if shapes and data are adapted to the selected validator profile.
- pySHACL: the current independent validator. Run through `cmd /c make validate-shacl` or full `cmd /c make validate`.

## Handoff Checklist For D Group

- Receive `model/v0.3/data-product-metadata-shapes.ttl`.
- Receive `model/v0.3/data-product-valid.jsonld`.
- Receive `model/v0.2/data-product-invalid.jsonld` for negative-case demonstration.
- Optionally receive `model/v0.3/energy-reading-record-shapes.ttl` and record examples.
- Run `cmd /c make validate-shacl` or `python C_Semantic_Treehouse\scripts\validate_shacl.py`.
- Include `validation/pyshacl-validation-report.md` in the validation story.
