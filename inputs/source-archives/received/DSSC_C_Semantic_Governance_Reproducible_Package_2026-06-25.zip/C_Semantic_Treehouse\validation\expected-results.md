# Expected Validation Results

## RDF

All Turtle artifacts in `model/v0.1`, `model/v0.2`, and `model/v0.3` should parse successfully.

## JSON-LD

All JSON-LD contexts and examples should parse as JSON and expand through JSON-LD processing. Local sibling context files are inlined by the validation harness so validation does not depend on network access.

## SHACL

Expected conforming cases:

- `model/v0.1/data-product-valid.jsonld` conforms to `model/v0.1/data-product-metadata-shapes.ttl`.
- `model/v0.2/data-product-valid.jsonld` conforms to `model/v0.2/data-product-metadata-shapes.ttl`.
- `model/v0.3/data-product-valid.jsonld` conforms to `model/v0.3/data-product-metadata-shapes.ttl`.
- `model/v0.3/energy-reading-record-valid.jsonld` conforms to `model/v0.3/energy-reading-record-shapes.ttl`.

Expected failing case:

- `model/v0.2/data-product-invalid.jsonld` must fail because:
  - `providerName` is missing.
  - `unit` is `MWh` instead of `kWh`.
  - `temporalEnd` is missing.

This expected failure is a successful harness outcome.

## JSON Schema

Expected conforming case:

- `model/v0.3/energy-reading-record-valid.jsonld` conforms to `model/v0.3/energy-reading-record.schema.json`.

Expected failing case:

- `model/v0.3/energy-reading-record-invalid.jsonld` must fail because it violates required field, type/format, and unit constraints:
  - `meterId` is missing.
  - `timestamp` is not a valid `date-time`.
  - `energyKWh` is a string instead of a number.
  - `unit` is `MWh` instead of `kWh`.

This expected failure is a successful harness outcome.

## OpenAPI

`model/v0.3/openapi-fragment.yaml` should parse as YAML, contain required top-level OpenAPI fields, and pass `openapi-spec-validator` when that optional package is available.
