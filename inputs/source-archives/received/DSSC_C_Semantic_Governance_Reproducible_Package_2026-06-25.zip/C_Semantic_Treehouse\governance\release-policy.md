# Release Policy

## Release Criteria

A model release is eligible when:

- Required artifacts exist for the target version.
- RDF/Turtle files parse.
- JSON-LD files expand.
- SHACL valid cases pass.
- SHACL invalid cases fail for expected reasons.
- JSON Schema record cases pass/fail as expected when record schema is in scope.
- OpenAPI fragments parse and pass available structural validation.
- SPARQL competency questions pass when relevant.
- SSSOM mapping table is parseable.
- Quality metrics are generated.
- Governance/provenance validation passes.

## Validation Gates

Required gates before handoff:

1. `make validate-rdf`
2. `make validate-jsonld`
3. `make validate-shacl`
4. `make validate-jsonschema`
5. `make validate-openapi`
6. `make test-sparql`
7. `make quality`
8. `make validate-governance`
9. `make validate`

## Semantic Versioning Interpretation

- Patch: documentation corrections or typo fixes that do not change model meaning.
- Minor: additive fields, optional constraints, mappings, or validation reports.
- Stricter minor with validation impact: new required constraints that do not remove existing fields but can reject older metadata.
- Major: removed fields, changed datatypes, changed field meaning, or incompatible validation behavior.

## Evidence Required for Release

- Validation reports under `validation/`.
- Changelog entry.
- Provenance JSON-LD update.
- Updated quality assessment.
- Updated handoff notes when downstream groups are affected.

## Rollback Policy

- Keep prior version artifacts available.
- Revert `dct:conformsTo` references to the last validated version when a release fails.
- Document rollback reason in the changelog.
- Re-run all validation gates after rollback.
