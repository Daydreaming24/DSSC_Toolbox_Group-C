#!/usr/bin/env sh
set -u

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
PACKAGE_DIR="$ROOT_DIR/C_Semantic_Treehouse"
UPSTREAM_DIR="$ROOT_DIR/tools/semantic-treehouse/upstream"
ENV_FILE="$UPSTREAM_DIR/.env"
EVIDENCE_DIR="$PACKAGE_DIR/evidence"
COMPOSE_MARKER="$EVIDENCE_DIR/treehouse-compose-file.txt"
LOG_FILE="$EVIDENCE_DIR/treehouse-docker-compose.log"
PROJECT_NAME="dssc_treehouse_evidence"

if [ -f "$COMPOSE_MARKER" ]; then
  COMPOSE_FILE="$(cat "$COMPOSE_MARKER")"
  docker compose -p "$PROJECT_NAME" --project-directory "$UPSTREAM_DIR" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile dev down >> "$LOG_FILE" 2>&1
else
  echo "No Treehouse compose file marker found; nothing to stop." | tee -a "$LOG_FILE"
fi
