$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDir = Split-Path -Parent $ScriptDir
$RootDir = Split-Path -Parent $PackageDir
$UpstreamDir = Join-Path $RootDir "tools\semantic-treehouse\upstream"
$EnvFile = Join-Path $UpstreamDir ".env"
$EvidenceDir = Join-Path $PackageDir "evidence"
$ComposeMarker = Join-Path $EvidenceDir "treehouse-compose-file.txt"
$LogFile = Join-Path $EvidenceDir "treehouse-docker-compose.log"
$ProjectName = "dssc_treehouse_evidence"

if (Test-Path $ComposeMarker) {
    $ComposeFile = (Get-Content -Raw -Encoding UTF8 $ComposeMarker).Trim()
    docker compose -p $ProjectName --project-directory $UpstreamDir --env-file $EnvFile -f $ComposeFile --profile dev down *>> $LogFile
    exit $LASTEXITCODE
}

"No Treehouse compose file marker found; nothing to stop." | Tee-Object -Append -FilePath $LogFile
exit 0
