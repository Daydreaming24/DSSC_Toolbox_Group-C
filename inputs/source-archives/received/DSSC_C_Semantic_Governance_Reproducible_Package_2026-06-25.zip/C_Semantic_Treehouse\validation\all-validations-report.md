# All Validations Report

Generated: 2026-06-25T10:00:15.476108+00:00

Overall status: PASS

## Checks

### validate_rdf.py

Status: PASS

Command: `C:\Users\12491\AppData\Local\Programs\Python\Python312\python.exe scripts/validate_rdf.py`
Exit code: 0

```text
RDF validation report: validation/rdf-validation-report.md
```

### validate_shacl.py

Status: PASS

Command: `C:\Users\12491\AppData\Local\Programs\Python\Python312\python.exe scripts/validate_shacl.py`
Exit code: 0

```text
pySHACL validation report: validation/pyshacl-validation-report.md
```

### validate_jsonld.py

Status: PASS

Command: `C:\Users\12491\AppData\Local\Programs\Python\Python312\python.exe scripts/validate_jsonld.py`
Exit code: 0

```text
JSON-LD validation report: validation/jsonld-validation-report.md
```

### validate_jsonschema.py

Status: PASS

Command: `C:\Users\12491\AppData\Local\Programs\Python\Python312\python.exe scripts/validate_jsonschema.py`
Exit code: 0

```text
JSON Schema validation report: validation/jsonschema-validation-report.md
```

### validate_openapi.py

Status: PASS

Command: `C:\Users\12491\AppData\Local\Programs\Python\Python312\python.exe scripts/validate_openapi.py`
Exit code: 0

```text
OpenAPI validation report: validation/openapi-validation-report.md
```
