from __future__ import annotations

try:
    from pyld import jsonld
except ModuleNotFoundError as exc:
    from validation_common import dependency_error

    raise dependency_error("pyld") from exc

from validation_common import CheckResult, ROOT, VALIDATION_DIR, load_json, relative, write_report


GOVERNANCE_DIR = ROOT / "governance"

EXPECTED_FILES = [
    "model-card.md",
    "changelog.md",
    "namespace-policy.md",
    "release-policy.md",
    "deprecation-policy.md",
    "review-workflow.md",
    "provenance.jsonld",
]

REQUIRED_MODEL_CARD_SECTIONS = [
    "## Model Name",
    "## Scope",
    "## Intended Users",
    "## Intended Use",
    "## Out-of-Scope Use",
    "## Standards Reused",
    "## Validation Strategy",
    "## Risks",
    "## Maintenance Owner",
    "## Review Status",
]


def file_exists_checks() -> list[CheckResult]:
    results = []
    for file_name in EXPECTED_FILES:
        path = GOVERNANCE_DIR / file_name
        if path.exists() and path.stat().st_size > 0:
            results.append(CheckResult(f"{file_name} exists", True, f"`{relative(path)}` exists and is non-empty."))
        else:
            results.append(CheckResult(f"{file_name} exists", False, f"`{relative(path)}` is missing or empty."))
    return results


def contains_all(path_name: str, needles: list[str], check_name: str) -> CheckResult:
    path = GOVERNANCE_DIR / path_name
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    missing = [needle for needle in needles if needle not in text]
    if missing:
        return CheckResult(check_name, False, f"Missing required content in `{relative(path)}`: {', '.join(missing)}")
    return CheckResult(check_name, True, f"`{relative(path)}` contains all required content.")


def validate_provenance() -> CheckResult:
    path = GOVERNANCE_DIR / "provenance.jsonld"
    try:
        document = load_json(path)
        expanded = jsonld.expand(document)
        graph = document.get("@graph", []) if isinstance(document, dict) else []
        ids = {node.get("@id") for node in graph if isinstance(node, dict)}
        required_ids = {
            "https://w3id.org/dssc-demo/building-energy/v0.1",
            "https://w3id.org/dssc-demo/building-energy/v0.2",
            "https://w3id.org/dssc-demo/building-energy/v0.3",
            "https://w3id.org/dssc-demo/building-energy/activity/model-generation",
            "https://w3id.org/dssc-demo/agents/c-group",
        }
        missing = sorted(required_ids - ids)
        if missing:
            return CheckResult("provenance.jsonld parse and required IDs", False, f"Missing IDs: {missing}")
        return CheckResult(
            "provenance.jsonld parse and required IDs",
            True,
            f"`{relative(path)}` parsed and expanded into {len(expanded)} top-level node(s).",
        )
    except Exception as exc:
        return CheckResult("provenance.jsonld parse and required IDs", False, f"{exc.__class__.__name__}: {exc}")


def main() -> int:
    results: list[CheckResult] = []
    results.extend(file_exists_checks())
    results.append(contains_all("model-card.md", REQUIRED_MODEL_CARD_SECTIONS, "model-card required sections"))
    results.append(contains_all("changelog.md", ["## v0.1", "## v0.2", "## v0.3"], "changelog version entries"))
    results.append(contains_all("release-policy.md", ["## Validation Gates", "make validate-rdf", "make validate-governance", "make validate"], "release policy validation gates"))
    results.append(contains_all("namespace-policy.md", ["https://w3id.org/dssc-demo/building-energy#", "v0.1", "v0.2", "v0.3"], "namespace policy version IRIs"))
    results.append(validate_provenance())

    ok = write_report(
        VALIDATION_DIR / "governance-validation-report.md",
        "Governance Validation Report",
        results,
        notes=["Governance validation checks document completeness and machine-readable provenance parseability."],
    )
    print(f"Governance validation report: {relative(VALIDATION_DIR / 'governance-validation-report.md')}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
