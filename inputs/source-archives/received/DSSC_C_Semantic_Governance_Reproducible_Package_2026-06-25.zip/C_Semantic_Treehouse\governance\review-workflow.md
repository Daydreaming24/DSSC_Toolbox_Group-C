# Review Workflow

## 1. Proposal

A change starts as a proposal describing the problem, affected fields, expected downstream impact, and target version.

## 2. Automated Checks

Run:

```sh
make validate
```

The release cannot proceed while required validation gates fail.

## 3. Semantic Reviewer

The semantic reviewer checks:

- term naming
- external standards reuse
- SSSOM mappings
- JSON-LD context behavior
- SHACL constraint clarity
- version compatibility

## 4. Domain Reviewer

The domain reviewer checks:

- energy data meaning
- required business fields
- unit interpretation
- temporal and spatial coverage
- API payload plausibility

## 5. Approval

Approval requires:

- automated validation reports
- semantic reviewer approval
- domain reviewer approval
- updated governance documentation

## 6. Release

Release steps:

1. Update version artifacts.
2. Update changelog.
3. Update provenance metadata.
4. Run all validation gates.
5. Publish artifacts or handoff package.

## 7. Publication

Publication means the release artifacts can be referenced by `dct:conformsTo` and shared with downstream groups.

## 8. Downstream Handoff

- A Group receives metadata requirements and model version URI.
- D Group receives SHACL shapes, examples, and expected validation results.
- B Group may reference the model URI and provenance in service offering credentials.
