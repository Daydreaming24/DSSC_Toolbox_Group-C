from __future__ import annotations

from pathlib import Path

from rdflib import Graph, Literal, URIRef

from validation_common import CheckResult, MODEL_DIR, ROOT, VALIDATION_DIR, relative, write_report


TEST_DIR = ROOT / "tests" / "sparql"
QUERY_DIR = TEST_DIR / "queries"
EXPECTED_DIR = TEST_DIR / "expected"


def load_test_graph() -> Graph:
    graph = Graph()
    graph.parse((MODEL_DIR / "v0.3" / "building-energy-ontology.ttl").as_uri(), format="turtle")
    graph.parse((MODEL_DIR / "v0.3" / "data-product-valid.jsonld").as_uri(), format="json-ld")
    graph.parse((MODEL_DIR / "v0.3" / "energy-reading-record-valid.jsonld").as_uri(), format="json-ld")
    return graph


def cell_to_text(value: object) -> str:
    if isinstance(value, URIRef):
        return str(value)
    if isinstance(value, Literal):
        return str(value)
    if value is None:
        return ""
    return str(value)


def query_results_to_tsv(graph: Graph, query_text: str) -> str:
    result = graph.query(query_text)
    headers = [str(variable) for variable in result.vars]
    rows = []
    for row in result:
        rows.append([cell_to_text(row.get(variable)) for variable in result.vars])
    rows.sort()
    return "\n".join(["\t".join(headers)] + ["\t".join(row) for row in rows]).strip()


def run_case(query_path: Path, graph: Graph) -> CheckResult:
    expected_path = EXPECTED_DIR / f"{query_path.stem}.tsv"
    if not expected_path.exists():
        return CheckResult(query_path.stem, False, f"Missing expected file: `{relative(expected_path)}`")

    query_text = query_path.read_text(encoding="utf-8")
    expected = expected_path.read_text(encoding="utf-8").strip()
    try:
        actual = query_results_to_tsv(graph, query_text)
    except Exception as exc:
        return CheckResult(query_path.stem, False, f"{exc.__class__.__name__}: {exc}")

    passed = actual == expected
    detail = [
        f"Query: `{relative(query_path)}`",
        f"Expected: `{relative(expected_path)}`",
        "",
        "Expected TSV:",
        "```text",
        expected,
        "```",
        "",
        "Actual TSV:",
        "```text",
        actual,
        "```",
    ]
    return CheckResult(query_path.stem, passed, "\n".join(detail))


def main() -> int:
    graph = load_test_graph()
    query_files = sorted(QUERY_DIR.glob("cq*.rq"))
    results = [run_case(path, graph) for path in query_files]
    if not query_files:
        results.append(CheckResult("SPARQL query discovery", False, "No `cq*.rq` files found."))
    ok = write_report(
        VALIDATION_DIR / "sparql-competency-question-report.md",
        "SPARQL Competency Question Report",
        results,
        notes=[
            "The test graph loads v0.3 ontology, v0.3 valid data product metadata, and v0.3 valid Energy Reading Record.",
            "CQ7 checks the model version binding through dct:conformsTo.",
        ],
    )
    print(f"SPARQL competency question report: {relative(VALIDATION_DIR / 'sparql-competency-question-report.md')}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
