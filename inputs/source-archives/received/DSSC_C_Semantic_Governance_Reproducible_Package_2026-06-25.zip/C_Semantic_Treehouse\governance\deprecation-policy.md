# Deprecation Policy

## Deprecating Fields

To deprecate a field:

1. Open a model change proposal.
2. Identify all affected artifacts: ontology, SHACL, JSON-LD context, JSON Schema, OpenAPI, SSSOM, examples, reports, and handoff files.
3. Mark the field as deprecated in the changelog and ontology documentation.
4. Add a replacement field or explain why no replacement exists.
5. Provide a migration note for A Group and D Group.

## Replacement Field Documentation

Every deprecated field must document:

- deprecated field IRI
- replacement field IRI
- reason for replacement
- first deprecated version
- last supported version if known
- impact on validation and examples

## Compatibility Expectations

- Deprecation alone should not break validation.
- Removal or datatype change is a breaking change.
- D Group must receive updated SHACL shapes before stricter validation is enforced.
- A Group must receive updated metadata requirements before connector/offering metadata is expected to change.
