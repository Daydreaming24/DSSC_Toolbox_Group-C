#!/usr/bin/env sh
set -u

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
PACKAGE_DIR="$ROOT_DIR/C_Semantic_Treehouse"
EVIDENCE_DIR="$PACKAGE_DIR/evidence"
PS_FILE="$EVIDENCE_DIR/treehouse-docker-ps.txt"
PROJECT_NAME="dssc_treehouse_evidence"

mkdir -p "$EVIDENCE_DIR"
docker ps --filter "label=com.docker.compose.project=$PROJECT_NAME" > "$PS_FILE" 2>&1 || true
cat "$PS_FILE"
