# Namespace Policy

## Base Namespace

Base namespace:

```text
https://w3id.org/dssc-demo/building-energy#
```

Preferred prefix:

```text
be
```

## Version IRIs

Released version IRIs:

- `https://w3id.org/dssc-demo/building-energy/v0.1`
- `https://w3id.org/dssc-demo/building-energy/v0.2`
- `https://w3id.org/dssc-demo/building-energy/v0.3`

Version IRIs identify model releases. They must be used in `dct:conformsTo` links from data product metadata.

## Local Term Rules

- Create local `be:*` terms only when a direct external term would be misleading or too heavy for the minimal demo.
- Every local class and property must have `rdfs:label` and `rdfs:comment`.
- Local terms should be stable after release.
- Local property names should match the assignment field names where practical.

## External Reuse Rules

- Prefer DCAT/DCTERMS for catalogue and data service metadata.
- Prefer SOSA/SSN for observation, sensor, and feature-of-interest patterns.
- Prefer QUDT/UCUM for unit identifiers in richer profiles.
- Prefer OWL-Time or XSD temporal datatypes for temporal coverage.
- Record all non-trivial alignments in `mappings/external-standard-alignment.sssom.tsv`.

## Deprecation Rules

- Do not delete released terms from documentation.
- Mark deprecated terms in changelog and future ontology releases.
- Provide replacement terms and migration guidance.
- Treat datatype changes, required-field removals, and semantic meaning changes as breaking changes.
