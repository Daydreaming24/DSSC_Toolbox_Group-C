# C Group Semantic Governance Package

This package is the working area for DSSC C Group: Semantic Treehouse / Semantic Model Governance.

The goal is to build a reproducible semantic governance package for the Building Energy Consumption Data Product. The package must remain useful even when a Semantic Treehouse deployment is unavailable: independent local validation is the core path, and Semantic Treehouse is a separate evidence track.

## Scope

C Group owns the shared semantic model layer. It does not implement the connector, trust service, or conformance test bed directly. It produces artifacts that A Group can use for data offering metadata and D Group can use for SHACL validation.

## Scenario

- Data Product: Building Energy Consumption Dataset API
- Dataset ID: `building-energy-hourly-v1`
- Provider: Energy Data Provider Ltd.
- Consumer: City Analytics Lab
- Data Space Authority: City Energy Data Space Authority
- Format: JSON
- Frequency: hourly
- Unit: kWh
- Endpoint: `https://api.example.org/energy/buildings/hourly`
- Spatial Coverage: Shenzhen demo district
- Temporal Coverage: 2026-05-01 to 2026-05-02

## Checklist

Minimum:

- Two models: Data Product Metadata and Energy Reading Record
- v0.1, v0.2, and v0.3 version evolution
- SHACL or equivalent validation artifacts
- Semantic Treehouse usage or deployment record
- Relationship diagram

Excellent:

- Alignment to DCAT/DCAT-AP, SOSA/SSN, QUDT/UCUM, and OWL-Time
- JSON-LD context, SHACL, JSON Schema, and OpenAPI fragment
- Valid and invalid validation reports
- A/D Group handoff contracts
- Model changelog, namespace policy, and release policy

Top-tier:

- SSSOM semantic mapping table
- CI validation pipeline
- SPARQL competency questions
- Provenance and version governance metadata
- Semantic Treehouse plus independent local validation evidence
- Model quality assessment: coverage, constraint strength, reuse ratio, and breaking-change risk
- AI-assisted but human-governed semantic modeling chapter

## Quickstart

From the repository root:

```sh
make help
make validate
```

On Windows without GNU Make, use the included compatibility wrapper:

```bat
cmd /c make help
cmd /c make validate
```

Phase 0 only provides scaffolding and validation stubs. Later phases will replace stubs with concrete scripts and reports.

## Expected Final Structure

```text
C_Semantic_Treehouse/
  README.md
  C_semantic_model_design.md
  C_semantic_treehouse_usage.md
  C_model_versioning_demo.md
  C_export_for_validation.md
  diagrams/
  model/
    v0.1/
    v0.2/
    v0.3/
  mappings/
  governance/
  validation/
  handoff/
  quality/
  evidence/
  docs/
  scripts/
  tests/
  sparql/
  fixtures/
```

The root `.github/workflows/` directory is reserved for CI in a later phase.
