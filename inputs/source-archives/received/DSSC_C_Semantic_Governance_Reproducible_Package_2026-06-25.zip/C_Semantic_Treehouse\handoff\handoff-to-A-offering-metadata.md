# Handoff To A Group - Offering Metadata Contract

## Required Metadata Fields

A Group should include these fields in the data offering metadata for the Building Energy Consumption Data Product:

| Field | Required value or rule |
|---|---|
| `datasetId` | `building-energy-hourly-v1` |
| `providerName` | `Energy Data Provider Ltd.` |
| `endpointUrl` | `https://api.example.org/energy/buildings/hourly` |
| `format` | `JSON` |
| `frequency` | `hourly` |
| `unit` | `kWh` |
| `spatialCoverage` | `Shenzhen demo district` |
| `temporalStart` | `2026-05-01` |
| `temporalEnd` | `2026-05-02` |

## JSON-LD Example

```json
{
  "@context": "C_Semantic_Treehouse/model/v0.3/data-product-context.jsonld",
  "@id": "https://w3id.org/dssc-demo/building-energy/data-product/building-energy-hourly-v1",
  "@type": "DataProductMetadata",
  "datasetId": "building-energy-hourly-v1",
  "providerName": "Energy Data Provider Ltd.",
  "endpointUrl": "https://api.example.org/energy/buildings/hourly",
  "format": "JSON",
  "frequency": "hourly",
  "unit": "kWh",
  "spatialCoverage": "Shenzhen demo district",
  "temporalStart": "2026-05-01",
  "temporalEnd": "2026-05-02",
  "conformsTo": "https://w3id.org/dssc-demo/building-energy/v0.3"
}
```

The complete validated example is `C_Semantic_Treehouse/model/v0.3/data-product-valid.jsonld`.

## `dct:conformsTo` Model Version URI

A Group should include:

```text
https://w3id.org/dssc-demo/building-energy/v0.3
```

This gives D Group and catalogue consumers an explicit validation target.

## Endpoint / DataService Recommendation

Use `endpointUrl` as the operational API endpoint and align it to DCAT DataService semantics:

- endpoint IRI: `https://api.example.org/energy/buildings/hourly`
- endpoint property in this profile: `be:endpointUrl`
- external alignment: `dcat:endpointURL`

If A Group models a full `dcat:DataService`, it should connect the service back to the dataset/offering and expose the same endpoint URL.

## What A Group Should Include In The Data Offering

- All nine required metadata fields above.
- `dct:conformsTo` pointing to v0.3.
- A link or attachment to `model/v0.3/openapi-fragment.yaml`.
- A statement that payload records conform to `model/v0.3/energy-reading-record.schema.json`.
- The unit contract `kWh`, because D Group validation rejects other units under this profile.
