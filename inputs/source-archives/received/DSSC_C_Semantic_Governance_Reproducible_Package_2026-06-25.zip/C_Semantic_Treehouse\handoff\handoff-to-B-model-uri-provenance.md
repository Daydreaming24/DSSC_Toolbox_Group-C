# Handoff To B Group - Model URI And Provenance Reference

## Purpose

B Group can optionally reference the C Group semantic model URI and provenance metadata when describing connector behavior, policy references, provenance, or integration evidence. This file does not introduce a new model; it only identifies stable references already produced by C Group.

## Model Version URI

Use the v0.3 model version IRI when referencing the current semantic contract:

```text
https://w3id.org/dssc-demo/building-energy/v0.3
```

This is the same URI used by `dct:conformsTo` in `model/v0.3/data-product-valid.jsonld`.

## Provenance Metadata

Machine-readable provenance is available at:

```text
C_Semantic_Treehouse/governance/provenance.jsonld
```

The provenance file records model versions as generated entities, the generation activity, responsible agent, derivation from v0.1 to v0.2 to v0.3, and validation reports as generated artifacts.

## Recommended Reference Pattern

B Group can record:

- semantic model URI: `https://w3id.org/dssc-demo/building-energy/v0.3`
- namespace: `https://w3id.org/dssc-demo/building-energy#`
- validation report: `C_Semantic_Treehouse/validation/all-validations-report.md`
- provenance metadata: `C_Semantic_Treehouse/governance/provenance.jsonld`

## Boundaries

- B Group should not change C Group SHACL constraints without a model change proposal.
- B Group can reference the model URI and provenance in connector or policy documentation.
- A Group remains responsible for offering metadata fields.
- D Group remains responsible for SHACL/validator execution.
