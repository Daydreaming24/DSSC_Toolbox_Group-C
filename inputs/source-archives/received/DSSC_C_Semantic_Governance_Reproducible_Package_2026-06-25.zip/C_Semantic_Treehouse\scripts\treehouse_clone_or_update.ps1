$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDir = Split-Path -Parent $ScriptDir
$RootDir = Split-Path -Parent $PackageDir
$ToolsDir = Join-Path $RootDir "tools\semantic-treehouse"
$UpstreamDir = Join-Path $ToolsDir "upstream"
$EvidenceDir = Join-Path $PackageDir "evidence"
$RepoUrl = "https://gitlab.com/semantic-treehouse/semantic-treehouse.git"

New-Item -ItemType Directory -Force $ToolsDir, $EvidenceDir | Out-Null

if (Test-Path (Join-Path $UpstreamDir ".git")) {
    git -C $UpstreamDir fetch --all --tags
} elseif (Test-Path $UpstreamDir) {
    throw "Refusing to overwrite non-git path: $UpstreamDir"
} else {
    git clone $RepoUrl $UpstreamDir
}

$Commit = (git -C $UpstreamDir rev-parse HEAD).Trim()
Set-Content -Encoding UTF8 -Path (Join-Path $EvidenceDir "semantic-treehouse-upstream-version.txt") -Value $Commit
Write-Output "Semantic Treehouse upstream commit: $Commit"
