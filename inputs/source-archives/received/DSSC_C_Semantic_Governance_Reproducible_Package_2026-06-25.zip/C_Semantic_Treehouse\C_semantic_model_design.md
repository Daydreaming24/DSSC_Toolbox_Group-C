# C Semantic Model Design

## Scope And Purpose

This package defines a small, governable semantic model for the Building Energy Consumption Data Product. It covers two related models:

- Data Product Metadata: catalogue, connector offering, and SHACL validation metadata for `building-energy-hourly-v1`.
- Energy Reading Record: one API payload record returned by `GET /energy/buildings/hourly`.

The design is intentionally minimal. It does not try to build a complete energy ontology; it defines the common semantic contract needed by the C Group task and the A/D downstream handoffs.

## DSSC Architecture Position

The model sits between catalogue/offering publication and validation. A provider publishes metadata, A Group can reuse the same required fields in a data offering, and D Group can validate the metadata with SHACL before onboarding or ITB-style validation. The v0.3 API record model also connects semantic governance to the mock API/OpenAPI layer.

## Reuse-First Design Principle

Local `be:*` terms are used only where the assignment requires compact field names or where the demo needs a lightweight profile. External standards are reused through subclassing, subproperties, JSON-LD context mappings, and the SSSOM table in `mappings/external-standard-alignment.sssom.tsv`.

## Namespace Policy

- Base namespace: `https://w3id.org/dssc-demo/building-energy#`
- Prefix: `be`
- Version IRIs:
  - `https://w3id.org/dssc-demo/building-energy/v0.1`
  - `https://w3id.org/dssc-demo/building-energy/v0.2`
  - `https://w3id.org/dssc-demo/building-energy/v0.3`

Released metadata uses `dct:conformsTo` to declare the exact version. The detailed governance rule is in `governance/namespace-policy.md`.

## Conceptual Model

The conceptual relationship is captured in `diagrams/metadata-record-model.mmd`. The provider publishes `be:DataProductMetadata`; the metadata conforms to a versioned model, is validated by SHACL, references a data service endpoint, and the API returns `be:EnergyReadingRecord` instances. Each record includes a building identifier, meter identifier, timestamp, energy value, unit, and lightweight location object.

## Data Product Metadata Model

The v0.3 metadata contract is implemented by:

- `model/v0.3/building-energy-ontology.ttl`
- `model/v0.3/data-product-metadata-shapes.ttl`
- `model/v0.3/data-product-context.jsonld`
- `model/v0.3/data-product-valid.jsonld`

Required fields are `datasetId`, `providerName`, `endpointUrl`, `format`, `frequency`, `unit`, `spatialCoverage`, `temporalStart`, and `temporalEnd`. The valid example declares:

- dataset ID: `building-energy-hourly-v1`
- provider: `Energy Data Provider Ltd.`
- endpoint: `https://api.example.org/energy/buildings/hourly`
- format/frequency/unit: `JSON`, `hourly`, `kWh`
- coverage: `Shenzhen demo district`, `2026-05-01` to `2026-05-02`

## Energy Reading Record Model

The v0.3 record contract is implemented by:

- `model/v0.3/energy-reading-record-shapes.ttl`
- `model/v0.3/energy-reading-record-context.jsonld`
- `model/v0.3/energy-reading-record.schema.json`
- `model/v0.3/openapi-fragment.yaml`
- `model/v0.3/energy-reading-record-valid.jsonld`

Required fields are `buildingId`, `meterId`, `timestamp`, `energyKWh`, `unit`, and `location`. The valid example uses building `BLD-001`, meter `MTR-001`, timestamp `2026-05-01T00:00:00+08:00`, energy value `12.4`, and unit `kWh`.

## Alignment To DCAT/DCAT-AP, SOSA/SSN, QUDT/UCUM, OWL-Time

- DCAT/DCAT-AP: `be:DataProductMetadata` is modeled as a `dcat:Dataset` profile; endpoint semantics align to `dcat:endpointURL`.
- DCTERMS: dataset identifier uses `dct:identifier`; format, spatial coverage, and conformance are aligned through `dct:format`, `dct:spatial`, and `dct:conformsTo`.
- SOSA/SSN: `be:EnergyReadingRecord` is a lightweight `sosa:Observation`; building and meter identifiers are mapped to feature-of-interest and sensor patterns in SSSOM.
- QUDT/UCUM: `energyKWh` aligns to `qudt:numericValue`; `unit = kWh` is retained as a constrained literal in the minimal profile and mapped to QUDT/UCUM concepts.
- OWL-Time/XSD: temporal coverage uses `xsd:date`; record timestamps use `xsd:dateTime`; `temporalStart` and `temporalEnd` map to OWL-Time beginning/end patterns.

## SHACL Constraint Strategy

The SHACL strategy is versioned:

- v0.1 requires baseline metadata fields only.
- v0.2 adds `endpointUrl`, `unit`, `temporalStart`, and `temporalEnd` and constrains `format = JSON`, `frequency = hourly`, `unit = kWh`.
- v0.3 keeps the v0.2 metadata contract and adds record-level payload constraints.

The expected invalid v0.2 metadata fails because `providerName` and `temporalEnd` are missing and `unit` is `MWh`.

## JSON-LD Serialization Strategy

JSON-LD contexts keep the operational JSON field names stable while mapping them to semantic IRIs. This lets A Group and API consumers use compact field names without losing RDF semantics. Valid examples under `model/v0.*/` are both data examples and validation fixtures.

## OpenAPI / JSON Schema Relationship

`model/v0.3/energy-reading-record.schema.json` validates a single record payload. `model/v0.3/openapi-fragment.yaml` embeds the same field contract in the response schema for `GET /energy/buildings/hourly`, which returns an array of records.

## Competency Questions

SPARQL competency questions in `tests/sparql/competency-questions.md` verify that the RDF graph can answer governance questions about dataset identifier, provider, endpoint, format, frequency, unit, coverage, model version, and record fields. `validation/sparql-competency-question-report.md` shows all eight checks passing, including the `dct:conformsTo` model-version check.

## Model Quality Summary

`quality/model-quality-assessment.md` reports:

- field coverage: 15/15 required fields represented, 100.00%
- reuse ratio: 15/19 local modeled terms externally aligned, 78.95%
- SSSOM mapping rows: 23
- v0.1 to v0.2: stricter minor change with validation impact
- v0.2 to v0.3: additive extension

## Limitations

- Provider and location remain lightweight literals/objects rather than full organization/place nodes.
- Unit is constrained as literal `kWh`; a richer production profile should use explicit QUDT or UCUM IRIs.
- Temporal coverage uses dates rather than a full OWL-Time interval node.
- Semantic Treehouse evidence confirms local UI availability, not a complete manual modeling workflow.

## Future Extensions

- Replace provider string with an organization node using `dct:publisher` and `foaf:name` or schema.org.
- Represent location as a stable place IRI with geospatial metadata.
- Promote `unit` from a literal to a QUDT/UCUM identifier.
- Add a full `dcat:DataService` node and distribution metadata.
- Add API response arrays and catalogue records to the SHACL validation suite.
