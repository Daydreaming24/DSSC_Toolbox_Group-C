$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDir = Split-Path -Parent $ScriptDir
$RootDir = Split-Path -Parent $PackageDir
$UpstreamDir = Join-Path $RootDir "tools\semantic-treehouse\upstream"
$EnvFile = Join-Path $UpstreamDir ".env"
$EnvExampleFile = Join-Path $UpstreamDir ".env.example"
$EvidenceDir = Join-Path $PackageDir "evidence"
$LogFile = Join-Path $EvidenceDir "treehouse-docker-compose.log"
$PsFile = Join-Path $EvidenceDir "treehouse-docker-ps.txt"
$SmokeFile = Join-Path $EvidenceDir "treehouse-smoke-check.txt"
$ComposeCandidatesFile = Join-Path $EvidenceDir "treehouse-compose-candidates.txt"
$ComposeMarker = Join-Path $EvidenceDir "treehouse-compose-file.txt"
$ReportFile = Join-Path $EvidenceDir "semantic-treehouse-local-deployment.md"
$ProjectName = "dssc_treehouse_evidence"

New-Item -ItemType Directory -Force $EvidenceDir | Out-Null
$UtcNow = (Get-Date).ToUniversalTime().ToString("o")
Set-Content -Encoding UTF8 -Path $LogFile -Value "Semantic Treehouse deployment attempt`n$UtcNow`n"

function Append-Log($Text) {
    Add-Content -Encoding UTF8 -Path $LogFile -Value $Text
}

function Clean-NativeCaptureText($Text) {
    $CleanLines = New-Object System.Collections.Generic.List[string]
    foreach ($Line in ($Text -split "`r?`n")) {
        if ($Line -match '^(docker|curl)\.exe : (.*)$') {
            $CleanLines.Add($Matches[2])
            continue
        }
        if ($Line -match '^\s*At .+treehouse_up\.ps1:\d+ char:\d+') {
            continue
        }
        if ($Line -match '^\s*\+ .*$') {
            continue
        }
        if ($Line -match '^\s*\+ (CategoryInfo|FullyQualifiedErrorId)\s*:') {
            continue
        }
        $CleanLines.Add($Line)
    }
    return ($CleanLines -join "`n").Trim()
}

function Invoke-NativeCapture($Command, [string[]]$Arguments) {
    $OutFile = New-TemporaryFile
    $ErrFile = New-TemporaryFile
    try {
        & $Command @Arguments 1> $OutFile 2> $ErrFile
        $Code = $LASTEXITCODE
        $Stdout = if (Test-Path $OutFile) { Get-Content -Raw -Encoding UTF8 $OutFile } else { "" }
        $Stderr = if (Test-Path $ErrFile) { Get-Content -Raw -Encoding UTF8 $ErrFile } else { "" }
        $Text = (($Stdout, $Stderr) | Where-Object { $_ -and $_.Trim().Length -gt 0 }) -join "`n"
        $Text = Clean-NativeCaptureText $Text
        return [PSCustomObject]@{
            ExitCode = $Code
            Text = $Text
        }
    } finally {
        Remove-Item -Force $OutFile, $ErrFile -ErrorAction SilentlyContinue
    }
}

function Write-Report($Result, $Errors) {
    $DockerVersion = (& docker --version 2>&1) -join "`n"
    $ComposeVersion = (& docker compose version 2>&1) -join "`n"
    $Commit = if (Test-Path (Join-Path $EvidenceDir "semantic-treehouse-upstream-version.txt")) {
        (Get-Content -Raw -Encoding UTF8 (Join-Path $EvidenceDir "semantic-treehouse-upstream-version.txt")).Trim()
    } else {
        "not captured"
    }
    $ComposeFile = if (Test-Path $ComposeMarker) { (Get-Content -Raw -Encoding UTF8 $ComposeMarker).Trim() } else { "not selected" }
    $Smoke = if (Test-Path $SmokeFile) { (Get-Content -Raw -Encoding UTF8 $SmokeFile).Trim() } else { "not run" }
    $Body = @"
# Semantic Treehouse Local Deployment Evidence

## Environment

- Host OS: Windows / PowerShell evidence harness
- Docker: $DockerVersion
- Docker Compose: $ComposeVersion

## Docker Version

~~~text
$DockerVersion
$ComposeVersion
~~~

## Upstream Commit

~~~text
$Commit
~~~

## Commands Run

- `git clone` or `git fetch` through `make treehouse-clone`
- `docker volume create sth-app-data`
- `docker volume create sth-db2-data`
- copy `.env.example` to `.env` if `.env` is missing
- `docker compose -p $ProjectName --project-directory <upstream> --env-file <upstream>/.env -f <compose-file> --profile dev up -d --build` through `make treehouse-up`
- `docker compose ... exec -T --workdir /app backend-dev composer install --no-interaction`
- `docker compose ... exec -T --workdir /app backend-dev php bin/console doctrine:migrations:migrate --no-interaction`
- `docker compose ps` / `docker ps` through status capture

Selected compose file:

~~~text
$ComposeFile
~~~

## Result

$Result

## UI/API URLs Checked

~~~text
$Smoke
~~~

## Screenshots To Capture Manually

- Semantic Treehouse home page if a UI port is available.
- Specification or vocabulary list if accessible.
- API or documentation route if exposed by the upstream deployment.

## Errors And Interpretation

~~~text
$Errors
~~~

## Impact On C Group Deliverables

Semantic Treehouse local deployment is supporting evidence only. Failure does not block the semantic governance package because the RDF, JSON-LD, SHACL, JSON Schema, OpenAPI, SPARQL, quality, and governance validations run independently.

## Fallback Validation Path

Run:

~~~bat
cmd /c make validate
~~~
"@
    Set-Content -Encoding UTF8 -Path $ReportFile -Value $Body
}

Append-Log ((& docker --version 2>&1) -join "`n")
Append-Log ((& docker compose version 2>&1) -join "`n")

if (-not (Test-Path (Join-Path $UpstreamDir ".git"))) {
    $Message = "Upstream repository is missing. Run make treehouse-clone first."
    Append-Log $Message
    docker ps --filter "label=com.docker.compose.project=$ProjectName" *> $PsFile
    Write-Report "FAILED: upstream repository missing." $Message
    exit 1
}

$Commit = (& git -C $UpstreamDir rev-parse HEAD 2>&1).Trim()
Set-Content -Encoding UTF8 -Path (Join-Path $EvidenceDir "semantic-treehouse-upstream-version.txt") -Value $Commit

$Candidates = Get-ChildItem -Path $UpstreamDir -Recurse -File -Include "docker-compose*.yml","docker-compose*.yaml","compose*.yml","compose*.yaml" |
    Sort-Object FullName
$Candidates | ForEach-Object { $_.FullName } | Set-Content -Encoding UTF8 -Path $ComposeCandidatesFile

$RootCompose = Join-Path $UpstreamDir "docker-compose.yml"
$RootComposeYaml = Join-Path $UpstreamDir "docker-compose.yaml"
$ComposeFile = $Candidates | Where-Object { $_.FullName -ieq $RootCompose -or $_.FullName -ieq $RootComposeYaml } | Select-Object -First 1
if (-not $ComposeFile) {
    $ComposeFile = $Candidates | Where-Object { ($_.Name -match "dev" -or $_.FullName -match "dev") -and $_.FullName -notmatch "\\.gitlab\\" } | Select-Object -First 1
}
if (-not $ComposeFile) {
    $ComposeFile = $Candidates | Where-Object { $_.FullName -notmatch "\\.gitlab\\" } | Select-Object -First 1
}
if (-not $ComposeFile) {
    $ComposeFile = $Candidates | Select-Object -First 1
}

if (-not $ComposeFile) {
    $Message = "No Docker Compose file found under upstream repository."
    Append-Log $Message
    docker ps --filter "label=com.docker.compose.project=$ProjectName" *> $PsFile
    Set-Content -Encoding UTF8 -Path $SmokeFile -Value "No smoke check: no compose file found."
    Write-Report "FAILED: no Docker Compose file found." $Message
    exit 1
}

Set-Content -Encoding UTF8 -Path $ComposeMarker -Value $ComposeFile.FullName
Append-Log "Using compose file: $($ComposeFile.FullName)"

if ((-not (Test-Path $EnvFile)) -and (Test-Path $EnvExampleFile)) {
    Copy-Item -LiteralPath $EnvExampleFile -Destination $EnvFile
    Append-Log "Copied .env.example to .env for local evidence deployment."
}

Append-Log ((& docker volume create sth-app-data 2>&1) -join "`n")
Append-Log ((& docker volume create sth-db2-data 2>&1) -join "`n")

$ComposeArgs = @(
    "compose",
    "-p", $ProjectName,
    "--project-directory", $UpstreamDir,
    "--env-file", $EnvFile,
    "-f", $ComposeFile.FullName,
    "--profile", "dev"
)

$UpResult = Invoke-NativeCapture "docker" ($ComposeArgs + @("up", "-d", "--build"))
$ExitCode = $UpResult.ExitCode
$OutputText = $UpResult.Text
Append-Log $OutputText
$PostSetupText = ""

if ($ExitCode -ne 0 -and $OutputText -match "docker-credential") {
    $TempDockerConfig = Join-Path $RootDir ".docker-treehouse-temp"
    New-Item -ItemType Directory -Force $TempDockerConfig | Out-Null
    Set-Content -Encoding ASCII -Path (Join-Path $TempDockerConfig "config.json") -Value "{}"
    $OldDockerConfig = $env:DOCKER_CONFIG
    $env:DOCKER_CONFIG = $TempDockerConfig
    Append-Log "Retrying with temporary empty DOCKER_CONFIG because Docker credential helper failed."
    $UpResult = Invoke-NativeCapture "docker" ($ComposeArgs + @("up", "-d", "--build"))
    $ExitCode = $UpResult.ExitCode
    $OutputText = $UpResult.Text
    Append-Log $OutputText
    $env:DOCKER_CONFIG = $OldDockerConfig
    Remove-Item -Recurse -Force $TempDockerConfig -ErrorAction SilentlyContinue
}

if ($ExitCode -eq 0) {
    Append-Log "Running upstream post-start setup: composer install."
    $ComposerResult = Invoke-NativeCapture "docker" ($ComposeArgs + @("exec", "-T", "--workdir", "/app", "backend-dev", "composer", "install", "--no-interaction"))
    $ComposerExitCode = $ComposerResult.ExitCode
    $ComposerText = $ComposerResult.Text
    Append-Log $ComposerText
    $PostSetupText += "composer install exit code: $ComposerExitCode`n$ComposerText`n"
    if ($ComposerExitCode -ne 0) {
        $ExitCode = $ComposerExitCode
    }
}

if ($ExitCode -eq 0) {
    Append-Log "Running upstream post-start setup: doctrine migrations."
    $MigrationResult = Invoke-NativeCapture "docker" ($ComposeArgs + @("exec", "-T", "--workdir", "/app", "backend-dev", "php", "bin/console", "doctrine:migrations:migrate", "--no-interaction"))
    $MigrationExitCode = $MigrationResult.ExitCode
    $MigrationText = $MigrationResult.Text
    Append-Log $MigrationText
    $PostSetupText += "doctrine migrations exit code: $MigrationExitCode`n$MigrationText`n"
    if ($MigrationExitCode -ne 0) {
        $ExitCode = $MigrationExitCode
    }
}

& docker @ComposeArgs ps *> $PsFile

$ComposeText = Get-Content -Raw -Encoding UTF8 $ComposeFile.FullName
$Ports = @()
if ($ComposeText -match '["'']?(4200)\s*:\s*[0-9]{2,5}["'']?') {
    $Ports += $Matches[1]
}
if ($ComposeText -match '["'']?(8014)\s*:\s*[0-9]{2,5}["'']?') {
    $Ports += $Matches[1]
}
if ($Ports.Count -eq 0 -and $ComposeText -match '["'']?([0-9]{2,5})\s*:\s*[0-9]{2,5}["'']?') {
    $Ports += $Matches[1]
}
$SmokeResults = @()
if ($Ports.Count -gt 0) {
    foreach ($Port in ($Ports | Select-Object -Unique)) {
        $SmokeUrl = "http://localhost:$Port/"
        try {
            $CurlResult = Invoke-NativeCapture "curl.exe" @("-sS", "-I", "--max-time", "5", $SmokeUrl)
            $SmokeResults += "Smoke check: $SmokeUrl`ncurl exit code: $($CurlResult.ExitCode)`n$($CurlResult.Text)"
        } catch {
            $SmokeResults += "Smoke check: $SmokeUrl`nError: $($_.Exception.Message)"
        }
    }
    Set-Content -Encoding UTF8 -Path $SmokeFile -Value ($SmokeResults -join "`n---`n")
} else {
    Set-Content -Encoding UTF8 -Path $SmokeFile -Value "No host port mapping detected in compose file."
}

$SmokeText = if (Test-Path $SmokeFile) { Get-Content -Raw -Encoding UTF8 $SmokeFile } else { "" }
$SmokeInterpretation = "Smoke interpretation: "
if ($SmokeText -match 'http://localhost:4200/[\s\S]*?curl exit code: 0') {
    $SmokeInterpretation += "the documented Semantic Treehouse development UI at http://localhost:4200/ responded successfully. "
} else {
    $SmokeInterpretation += "the documented Semantic Treehouse development UI at http://localhost:4200/ did not return a successful smoke response. "
}
if ($SmokeText -match 'http://localhost:8014/[\s\S]*?curl exit code: 0') {
    $SmokeInterpretation += "The backend/root port at http://localhost:8014/ also responded. "
} elseif ($SmokeText -match 'http://localhost:8014/') {
    $SmokeInterpretation += "The backend/root port at http://localhost:8014/ is mapped by Compose, but the root HEAD smoke check did not return within the 5 second timeout. "
}
$SmokeInterpretation += "This is evidence-track information only and does not affect independent semantic validation."

if ($ExitCode -eq 0) {
    Write-Report "SUCCESS: Docker Compose command and upstream post-start setup completed. Inspect container status and smoke check for UI/API availability." "No fatal deployment command error captured.`n$PostSetupText`n$SmokeInterpretation"
} else {
    Write-Report "FAILED: deployment or post-start setup exited with code $ExitCode. Evidence logs were captured." "$OutputText`n$PostSetupText`n$SmokeInterpretation"
}

exit $ExitCode
