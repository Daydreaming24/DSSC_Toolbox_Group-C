# Handoff To D Group - SHACL Validation Contract

## Files D Group Receives

Metadata validation:

- `C_Semantic_Treehouse/model/v0.3/data-product-metadata-shapes.ttl`
- `C_Semantic_Treehouse/model/v0.3/data-product-valid.jsonld`
- `C_Semantic_Treehouse/model/v0.2/data-product-invalid.jsonld`

Optional record validation:

- `C_Semantic_Treehouse/model/v0.3/energy-reading-record-shapes.ttl`
- `C_Semantic_Treehouse/model/v0.3/energy-reading-record-valid.jsonld`
- `C_Semantic_Treehouse/model/v0.3/energy-reading-record-invalid.jsonld`
- `C_Semantic_Treehouse/model/v0.3/energy-reading-record.schema.json`

Reports:

- `C_Semantic_Treehouse/validation/pyshacl-validation-report.md`
- `C_Semantic_Treehouse/validation/jsonschema-validation-report.md`
- `C_Semantic_Treehouse/validation/all-validations-report.md`

## Commands To Validate

From the repository root:

```bat
cmd /c make validate-shacl
cmd /c make validate-jsonschema
cmd /c make validate
```

Direct script entry points:

```bat
python C_Semantic_Treehouse\scripts\validate_shacl.py
python C_Semantic_Treehouse\scripts\validate_jsonschema.py
```

## Expected Valid / Invalid Results

- v0.1 valid metadata: conforms.
- v0.2 valid metadata: conforms.
- v0.2 invalid metadata: does not conform, counted as expected validation success.
- v0.3 data product metadata: conforms.
- v0.3 energy reading record: conforms.
- v0.3 invalid record: fails JSON Schema as expected.

## Explanation Of Invalid Case

`model/v0.2/data-product-invalid.jsonld` must fail because:

- `providerName` is missing.
- `unit` is `MWh`, but the allowed value is `kWh`.
- `temporalEnd` is missing.

This negative case proves the validator is checking real constraints rather than only parsing files.

## ITB / SEMIC Validation Story

D Group can present this as a two-layer validation story:

1. Semantic contract validation with SHACL for RDF/JSON-LD metadata.
2. API payload validation with JSON Schema/OpenAPI for Energy Reading Record payloads.

For ITB or SEMIC-style validation, use the same shape/data pairs and expected pass/fail outcomes. If a validator requires a different packaging format, keep the constraints unchanged and document the packaging adapter separately.
