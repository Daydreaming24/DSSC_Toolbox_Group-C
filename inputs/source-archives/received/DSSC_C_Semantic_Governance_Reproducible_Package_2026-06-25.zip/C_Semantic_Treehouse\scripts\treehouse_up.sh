#!/usr/bin/env sh
set -u

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
PACKAGE_DIR="$ROOT_DIR/C_Semantic_Treehouse"
UPSTREAM_DIR="$ROOT_DIR/tools/semantic-treehouse/upstream"
ENV_FILE="$UPSTREAM_DIR/.env"
ENV_EXAMPLE_FILE="$UPSTREAM_DIR/.env.example"
EVIDENCE_DIR="$PACKAGE_DIR/evidence"
LOG_FILE="$EVIDENCE_DIR/treehouse-docker-compose.log"
PS_FILE="$EVIDENCE_DIR/treehouse-docker-ps.txt"
SMOKE_FILE="$EVIDENCE_DIR/treehouse-smoke-check.txt"
COMPOSE_MARKER="$EVIDENCE_DIR/treehouse-compose-file.txt"
REPORT_FILE="$EVIDENCE_DIR/semantic-treehouse-local-deployment.md"
PROJECT_NAME="dssc_treehouse_evidence"

mkdir -p "$EVIDENCE_DIR"
: > "$LOG_FILE"

{
  echo "Semantic Treehouse deployment attempt"
  date -u
  docker --version || true
  docker compose version || true
} >> "$LOG_FILE" 2>&1

if [ ! -d "$UPSTREAM_DIR/.git" ]; then
  echo "Upstream repository is missing. Run make treehouse-clone first." | tee -a "$LOG_FILE"
  docker ps --filter "label=com.docker.compose.project=$PROJECT_NAME" > "$PS_FILE" 2>&1 || true
  exit 1
fi

COMMIT="$(git -C "$UPSTREAM_DIR" rev-parse HEAD 2>/dev/null || true)"
printf '%s\n' "$COMMIT" > "$EVIDENCE_DIR/semantic-treehouse-upstream-version.txt"

find "$UPSTREAM_DIR" -maxdepth 3 \( -iname 'docker-compose*.yml' -o -iname 'docker-compose*.yaml' -o -iname 'compose*.yml' -o -iname 'compose*.yaml' \) | sort > "$EVIDENCE_DIR/treehouse-compose-candidates.txt"

ROOT_COMPOSE="$UPSTREAM_DIR/docker-compose.yml"
ROOT_COMPOSE_YAML="$UPSTREAM_DIR/docker-compose.yaml"
COMPOSE_FILE="$(grep -ix "$ROOT_COMPOSE" "$EVIDENCE_DIR/treehouse-compose-candidates.txt" | head -n 1 || true)"
if [ -z "$COMPOSE_FILE" ]; then
  COMPOSE_FILE="$(grep -ix "$ROOT_COMPOSE_YAML" "$EVIDENCE_DIR/treehouse-compose-candidates.txt" | head -n 1 || true)"
fi
if [ -z "$COMPOSE_FILE" ]; then
  COMPOSE_FILE="$(grep -vi '/.gitlab/' "$EVIDENCE_DIR/treehouse-compose-candidates.txt" | grep -i 'dev' | head -n 1 || true)"
fi
if [ -z "$COMPOSE_FILE" ]; then
  COMPOSE_FILE="$(grep -vi '/.gitlab/' "$EVIDENCE_DIR/treehouse-compose-candidates.txt" | head -n 1 || true)"
fi
if [ -z "$COMPOSE_FILE" ]; then
  COMPOSE_FILE="$(head -n 1 "$EVIDENCE_DIR/treehouse-compose-candidates.txt" || true)"
fi

if [ -z "$COMPOSE_FILE" ]; then
  echo "No Docker Compose file found under upstream repository." | tee -a "$LOG_FILE"
  docker ps --filter "label=com.docker.compose.project=$PROJECT_NAME" > "$PS_FILE" 2>&1 || true
  exit 1
fi

printf '%s\n' "$COMPOSE_FILE" > "$COMPOSE_MARKER"
echo "Using compose file: $COMPOSE_FILE" | tee -a "$LOG_FILE"

if [ ! -f "$ENV_FILE" ] && [ -f "$ENV_EXAMPLE_FILE" ]; then
  cp "$ENV_EXAMPLE_FILE" "$ENV_FILE"
  echo "Copied .env.example to .env for local evidence deployment." >> "$LOG_FILE"
fi

docker volume create sth-app-data >> "$LOG_FILE" 2>&1 || true
docker volume create sth-db2-data >> "$LOG_FILE" 2>&1 || true

docker compose -p "$PROJECT_NAME" --project-directory "$UPSTREAM_DIR" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile dev up -d --build >> "$LOG_FILE" 2>&1
STATUS="$?"
POST_SETUP_TEXT=""
if [ "$STATUS" -eq 0 ]; then
  echo "Running upstream post-start setup: composer install." >> "$LOG_FILE"
  docker compose -p "$PROJECT_NAME" --project-directory "$UPSTREAM_DIR" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile dev exec -T --workdir /app backend-dev composer install --no-interaction >> "$LOG_FILE" 2>&1
  COMPOSER_STATUS="$?"
  POST_SETUP_TEXT="${POST_SETUP_TEXT}
composer install exit code: $COMPOSER_STATUS"
  if [ "$COMPOSER_STATUS" -ne 0 ]; then
    STATUS="$COMPOSER_STATUS"
  fi
fi
if [ "$STATUS" -eq 0 ]; then
  echo "Running upstream post-start setup: doctrine migrations." >> "$LOG_FILE"
  docker compose -p "$PROJECT_NAME" --project-directory "$UPSTREAM_DIR" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile dev exec -T --workdir /app backend-dev php bin/console doctrine:migrations:migrate --no-interaction >> "$LOG_FILE" 2>&1
  MIGRATION_STATUS="$?"
  POST_SETUP_TEXT="${POST_SETUP_TEXT}
doctrine migrations exit code: $MIGRATION_STATUS"
  if [ "$MIGRATION_STATUS" -ne 0 ]; then
    STATUS="$MIGRATION_STATUS"
  fi
fi
docker compose -p "$PROJECT_NAME" --project-directory "$UPSTREAM_DIR" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile dev ps > "$PS_FILE" 2>&1 || true

PORTS="$(grep -Eo '4200:[0-9]{2,5}' "$COMPOSE_FILE" | cut -d: -f1 || true)"
PORTS="${PORTS}
$(grep -Eo '8014:[0-9]{2,5}' "$COMPOSE_FILE" | cut -d: -f1 || true)"
if [ -z "$(printf '%s' "$PORTS" | tr -d '[:space:]')" ]; then
  PORTS="$(grep -Eo '[0-9]{2,5}:[0-9]{2,5}' "$COMPOSE_FILE" | head -n 1 | cut -d: -f1 || true)"
fi
if [ -n "$(printf '%s' "$PORTS" | tr -d '[:space:]')" ]; then
  : > "$SMOKE_FILE"
  printf '%s\n' "$PORTS" | awk 'NF && !seen[$0]++' | while IFS= read -r PORT; do
    {
      echo "Smoke check: http://localhost:$PORT/"
      curl -I --max-time 5 "http://localhost:$PORT/" || true
      echo "---"
    } >> "$SMOKE_FILE" 2>&1
  done
else
  echo "No host port mapping detected in compose file." > "$SMOKE_FILE"
fi

SMOKE_INTERPRETATION="Smoke interpretation: "
if grep -A 20 'http://localhost:4200/' "$SMOKE_FILE" | grep -q 'HTTP/.* 200'; then
  SMOKE_INTERPRETATION="${SMOKE_INTERPRETATION}the documented Semantic Treehouse development UI at http://localhost:4200/ responded successfully. "
else
  SMOKE_INTERPRETATION="${SMOKE_INTERPRETATION}the documented Semantic Treehouse development UI at http://localhost:4200/ did not return a successful smoke response. "
fi
if grep -q 'http://localhost:8014/' "$SMOKE_FILE"; then
  if grep -A 20 'http://localhost:8014/' "$SMOKE_FILE" | grep -q 'HTTP/'; then
    SMOKE_INTERPRETATION="${SMOKE_INTERPRETATION}The backend/root port at http://localhost:8014/ responded. "
  else
    SMOKE_INTERPRETATION="${SMOKE_INTERPRETATION}The backend/root port at http://localhost:8014/ is mapped by Compose but the root smoke check did not return HTTP headers within the timeout. "
  fi
fi
SMOKE_INTERPRETATION="${SMOKE_INTERPRETATION}This is evidence-track information only and does not affect independent semantic validation."

{
  echo "# Semantic Treehouse Local Deployment Evidence"
  echo
  echo "## Environment"
  echo
  echo "- Host OS: POSIX shell evidence harness"
  echo "- Docker: $(docker --version 2>&1 || true)"
  echo "- Docker Compose: $(docker compose version 2>&1 || true)"
  echo
  echo "## Docker Version"
  echo
  echo "~~~text"
  docker --version 2>&1 || true
  docker compose version 2>&1 || true
  echo "~~~"
  echo
  echo "## Upstream Commit"
  echo
  echo "~~~text"
  printf '%s\n' "$COMMIT"
  echo "~~~"
  echo
  echo "## Commands Run"
  echo
  echo "- git clone or git fetch through make treehouse-clone"
  echo "- docker volume create sth-app-data"
  echo "- docker volume create sth-db2-data"
  echo "- copy .env.example to .env if .env is missing"
  echo "- docker compose -p $PROJECT_NAME --project-directory <upstream> --env-file <upstream>/.env -f <compose-file> --profile dev up -d --build"
  echo "- docker compose ... exec -T --workdir /app backend-dev composer install --no-interaction"
  echo "- docker compose ... exec -T --workdir /app backend-dev php bin/console doctrine:migrations:migrate --no-interaction"
  echo
  echo "Selected compose file:"
  echo
  echo "~~~text"
  printf '%s\n' "$COMPOSE_FILE"
  echo "~~~"
  echo
  echo "## Result"
  echo
  if [ "$STATUS" -eq 0 ]; then
    echo "SUCCESS: Docker Compose command completed. Inspect container status and smoke check for UI/API availability."
  else
    echo "FAILED: Docker Compose command exited with code $STATUS. Evidence logs were captured."
  fi
  echo
  echo "## UI/API URLs Checked"
  echo
  echo "~~~text"
  cat "$SMOKE_FILE" 2>/dev/null || true
  echo "~~~"
  echo
  echo "## Screenshots To Capture Manually"
  echo
  echo "- Semantic Treehouse home page if a UI port is available."
  echo "- Specification or vocabulary list if accessible."
  echo "- API or documentation route if exposed by the upstream deployment."
  echo
  echo "## Errors And Interpretation"
  echo
  echo "See treehouse-docker-compose.log for full deployment output."
  printf '%s\n' "$POST_SETUP_TEXT"
  printf '%s\n' "$SMOKE_INTERPRETATION"
  echo
  echo "## Impact On C Group Deliverables"
  echo
  echo "Semantic Treehouse local deployment is supporting evidence only. Failure does not block the semantic governance package because local validation runs independently."
  echo
  echo "## Fallback Validation Path"
  echo
  echo "~~~sh"
  echo "make validate"
  echo "~~~"
} > "$REPORT_FILE"

exit "$STATUS"
