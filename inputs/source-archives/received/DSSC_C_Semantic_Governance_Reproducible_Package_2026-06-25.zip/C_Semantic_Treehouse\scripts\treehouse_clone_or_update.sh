#!/usr/bin/env sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
PACKAGE_DIR="$ROOT_DIR/C_Semantic_Treehouse"
TOOLS_DIR="$ROOT_DIR/tools/semantic-treehouse"
UPSTREAM_DIR="$TOOLS_DIR/upstream"
EVIDENCE_DIR="$PACKAGE_DIR/evidence"
REPO_URL="https://gitlab.com/semantic-treehouse/semantic-treehouse.git"

mkdir -p "$TOOLS_DIR" "$EVIDENCE_DIR"

if [ -d "$UPSTREAM_DIR/.git" ]; then
  git -C "$UPSTREAM_DIR" fetch --all --tags
else
  if [ -e "$UPSTREAM_DIR" ]; then
    echo "Refusing to overwrite non-git path: $UPSTREAM_DIR" >&2
    exit 1
  fi
  git clone "$REPO_URL" "$UPSTREAM_DIR"
fi

COMMIT="$(git -C "$UPSTREAM_DIR" rev-parse HEAD)"
printf '%s\n' "$COMMIT" > "$EVIDENCE_DIR/semantic-treehouse-upstream-version.txt"
echo "Semantic Treehouse upstream commit: $COMMIT"
