# C Semantic Treehouse Usage

## Tool Positioning

Semantic Treehouse is treated as a semantic model governance and publication tool. In this package it is an evidence track, not the only source of truth. The authoritative validation path is the independent local harness under `scripts/` and `validation/`.

## Local Deployment Path

The local deployment harness is documented in `tools/semantic-treehouse/README.md` and implemented by:

- `scripts/treehouse_clone_or_update.ps1` / `.sh`
- `scripts/treehouse_up.ps1` / `.sh`
- `scripts/treehouse_down.ps1` / `.sh`
- `scripts/treehouse_status.ps1` / `.sh`

On Windows, `make.cmd` calls the PowerShell scripts. On POSIX systems, `Makefile` calls the shell scripts.

## Docker Evidence

`make treehouse-clone` cloned or fetched upstream Semantic Treehouse into `tools/semantic-treehouse/upstream`. The captured commit is stored in `evidence/semantic-treehouse-upstream-version.txt`.

`make treehouse-up` selected upstream `docker-compose.yml`, used `--profile dev`, created the required `sth-app-data` and `sth-db2-data` volumes, copied `.env.example` to `.env` when needed, ran `composer install`, and ran Doctrine migrations.

Evidence files:

- `evidence/semantic-treehouse-local-deployment.md`
- `evidence/treehouse-docker-compose.log`
- `evidence/treehouse-docker-ps.txt`
- `evidence/treehouse-smoke-check.txt`

The smoke check shows `http://localhost:4200/` returning `HTTP/1.1 200 OK`. The backend/root port `http://localhost:8014/` is mapped by Compose, but the root HEAD check timed out after 5 seconds. This is recorded as a partial smoke caveat, not hidden.

## UI/API Functionality To Confirm

The automated evidence confirms local UI availability at `http://localhost:4200/`. Manual confirmation should still capture screenshots for:

- the Semantic Treehouse home or login page
- specification or vocabulary listing
- message model or ontology workflow
- export controls if available
- validator or API routes if accessible in the local instance

## Message Model Workflow

The intended workflow is:

1. Create or import a message/semantic model for Data Product Metadata.
2. Create versions corresponding to v0.1, v0.2, and v0.3.
3. Define required fields and constraints.
4. Add the Energy Reading Record payload model in v0.3.
5. Record review and release status before downstream handoff.

The local evidence confirms the tool can be started locally, but the full UI workflow still requires manual operation and screenshots.

## Export Workflow

This package independently provides the export artifacts expected from a semantic model governance process:

- Turtle ontology: `model/v0.3/building-energy-ontology.ttl`
- SHACL shapes: `model/v0.3/data-product-metadata-shapes.ttl`, `model/v0.3/energy-reading-record-shapes.ttl`
- JSON-LD contexts and examples: `model/v0.3/*.jsonld`
- JSON Schema: `model/v0.3/energy-reading-record.schema.json`
- OpenAPI fragment: `model/v0.3/openapi-fragment.yaml`
- SSSOM mapping: `mappings/external-standard-alignment.sssom.tsv`

Semantic Treehouse export should be compared with these local artifacts if a manual UI export is completed.

## Validator Workflow

Validation is run independently:

```bat
cmd /c make validate
```

This executes RDF parsing, JSON-LD expansion, SHACL valid/invalid checks, JSON Schema checks, OpenAPI checks, SPARQL competency questions, quality metrics, and governance/provenance checks.

## Issues Encountered

- Windows did not provide a working POSIX shell path, so PowerShell wrappers were added.
- The upstream repository contains a CI image compose file under `.gitlab`; the harness was adjusted to prefer the root `docker-compose.yml`.
- The upstream README requires `composer install` and Doctrine migrations after compose startup; these were added to the harness.
- The UI smoke check succeeds on port `4200`, while the backend/root HEAD check on `8014` times out.

## Independent Validation Fallback

Semantic Treehouse availability is not required for validation. The local validation harness runs from repository artifacts and writes final reports under `validation/`. This satisfies the C Group requirement that the semantic model remains verifiable even if Semantic Treehouse cannot be deployed or fully exercised.

## Assessment: Strengths, Weaknesses, Deployment Risks

Strengths:

- Combines semantic model governance, versioning, publication, and export workflows.
- Aligns with the C Group objective of understanding model definition, maintenance, publication, and governance.
- Local deployment evidence demonstrates a concrete UI endpoint.

Weaknesses:

- Full UI workflow and screenshots remain manual.
- Local deployment is heavier than the semantic artifact validation harness.
- Backend/root route behavior needs further investigation if API-level Treehouse evidence is required.

Deployment risks:

- Upstream dependencies and Docker images can change.
- Local Docker environment and port conflicts can affect reproducibility.
- Semantic Treehouse should remain a parallel evidence track, not a blocking validation dependency.
