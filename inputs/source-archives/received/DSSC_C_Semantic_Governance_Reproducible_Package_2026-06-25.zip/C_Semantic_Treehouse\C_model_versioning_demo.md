# C Model Versioning Demo

## Versioning Policy

The model uses stable base namespace `https://w3id.org/dssc-demo/building-energy#` and explicit version IRIs. Data examples declare the target version through `dct:conformsTo`. The release policy is documented in `governance/release-policy.md`; deprecation rules are documented in `governance/deprecation-policy.md`.

## v0.1 Baseline

Artifacts:

- `model/v0.1/building-energy-ontology.ttl`
- `model/v0.1/data-product-metadata-shapes.ttl`
- `model/v0.1/data-product-context.jsonld`
- `model/v0.1/data-product-valid.jsonld`

v0.1 establishes `be:DataProductMetadata` and requires baseline fields: `datasetId`, `providerName`, `format`, `frequency`, and `spatialCoverage`.

## v0.2 Stricter Metadata Constraints

Artifacts:

- `model/v0.2/building-energy-ontology.ttl`
- `model/v0.2/data-product-metadata-shapes.ttl`
- `model/v0.2/data-product-context.jsonld`
- `model/v0.2/data-product-valid.jsonld`
- `model/v0.2/data-product-invalid.jsonld`

v0.2 adds required `endpointUrl`, `unit`, `temporalStart`, and `temporalEnd`. It also constrains `format` to `JSON`, `frequency` to `hourly`, and `unit` to `kWh`.

## v0.3 Record Payload Extension

Artifacts:

- `model/v0.3/building-energy-ontology.ttl`
- `model/v0.3/data-product-metadata-shapes.ttl`
- `model/v0.3/energy-reading-record-shapes.ttl`
- `model/v0.3/data-product-context.jsonld`
- `model/v0.3/energy-reading-record-context.jsonld`
- `model/v0.3/energy-reading-record.schema.json`
- `model/v0.3/openapi-fragment.yaml`

v0.3 keeps the v0.2 metadata contract and adds `be:EnergyReadingRecord` with `buildingId`, `meterId`, `timestamp`, `energyKWh`, `unit`, and `location`.

## Compatibility Matrix

| Change | Classification | Metadata impact | Payload impact | A Group impact | D Group impact |
|---|---|---|---|---|---|
| v0.1 to v0.2 | Stricter minor change with validation impact | Older metadata missing endpoint/unit/temporal coverage fails v0.2 | None | Offering metadata must include endpoint, unit, and temporal coverage | SHACL validation becomes stricter |
| v0.2 to v0.3 | Additive extension | Compatible with v0.2 metadata | Adds optional record validation layer | Offering/API docs can reference record schema | D can validate payload examples in addition to metadata |

## Changelog

The authoritative changelog is `governance/changelog.md`. Summary:

- v0.1: baseline metadata model.
- v0.2: stricter metadata constraints and invalid example.
- v0.3: record payload schema, OpenAPI fragment, and SPARQL competency questions.

## Deprecation Policy

Fields are not removed in this demo. Future deprecations must identify affected ontology, SHACL, JSON-LD context, JSON Schema, OpenAPI, SSSOM, examples, reports, and handoff documents. Deprecation alone should not break validation; removal or datatype change is treated as breaking.

## Impact On A Group

A Group should use the v0.3 metadata contract for data offering metadata:

- include all nine required metadata fields
- include `dct:conformsTo = https://w3id.org/dssc-demo/building-energy/v0.3`
- expose the API endpoint as a data service endpoint
- reference the Energy Reading Record schema in API/offering documentation when payload structure matters

## Impact On D Group

D Group receives the versioned SHACL shapes and examples. D should validate:

- v0.3 metadata valid example: conforms
- v0.2 invalid metadata example: fails for missing `providerName`, invalid `unit`, and missing `temporalEnd`
- v0.3 record valid example: conforms to record SHACL and JSON Schema
- v0.3 invalid record: fails JSON Schema as expected

## Evidence Files

- `validation/pyshacl-validation-report.md`
- `validation/jsonschema-validation-report.md`
- `validation/openapi-validation-report.md`
- `validation/sparql-competency-question-report.md`
- `quality/model-quality-assessment.md`
- `governance/provenance.jsonld`
- `evidence/semantic-treehouse-local-deployment.md`
